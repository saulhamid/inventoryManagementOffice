﻿export class Menus {
    userMenuId: string;
    userId: string;
    menuId: number;
    name:string;
    menuParentId:number;
    orderNo:number;
    isPermission:boolean;
    children:Menus[];
}