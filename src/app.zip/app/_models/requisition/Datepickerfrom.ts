export class Datepickerfrom{
    fromDate:any;
    //requisitionId:string;
    toDate:any;
}