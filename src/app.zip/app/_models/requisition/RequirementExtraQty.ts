export class RequirementExtraQty{
    requisitionDetailId:number;
    //requisitionId:string;
    extraQty:number;
}