export class RequisitionDetail {
    requisitionDetailId:string;
    requisitionId:string;
    productId:string;
    productName:string;
    rQty:string;
    categoryName:string;
    subcategoryName:string;
    noteText:string;
}
