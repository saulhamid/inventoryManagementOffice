﻿export class Role {
    id: string;
    Name: string;
}