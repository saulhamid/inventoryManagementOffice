export class Tramscondition {
    id: string;
    description: string;
    type:string;
    isActive:string;
}