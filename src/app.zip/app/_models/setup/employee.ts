export class Employee {
employeeId: string;
employeeName: string ;
mobile: string ;
address: string ;
email: string ;
joinDate: Date ;
branchId: number ;
branchName: string ;
sectionId: string ;
sectionName: string ;
departmentId: string ;
designationName: string;
departmentName: string;
}