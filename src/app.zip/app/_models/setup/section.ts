﻿export class Section {
    id: string;
    Id: string;
    Secname: string;
    secName: string;
    Seccode: string;
    secCode: string;
    branchId: string;
    branchName:string;
}