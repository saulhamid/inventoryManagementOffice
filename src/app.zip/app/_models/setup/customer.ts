export class Customer {
    customerId: string;
    customerCode: string ;
    customerName: string ;
    customerNameBangla: string ;
    dealerBussinessName: string ;
address: string ;
email: string ;
url: string ;
phoneNumber: string ;
webAddress: string ;
fax: string ;
}