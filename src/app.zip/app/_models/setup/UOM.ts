export class UOM {
    uomName: string;
    id: string;
    uomCode: string;
}