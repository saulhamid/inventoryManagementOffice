﻿export class Subcategory {
    id: string;
    name: string;
    code: string;
    categoryId: string;
    categoryName:string;
}