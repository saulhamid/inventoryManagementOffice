﻿export class Category {
    [x: string]: any;
    id: string;
    Id: string;
    name: string;
    code: string;
}