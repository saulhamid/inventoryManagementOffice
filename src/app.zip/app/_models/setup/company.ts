﻿export class Company {
    id: string;
    companyName: string;
    address: string;
    url: string;
    phone: string;
    mobile: string;
    fax: string;
    vatRegNo: string;
}