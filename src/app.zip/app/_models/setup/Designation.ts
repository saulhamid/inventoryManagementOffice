export class Designation {
    designationName: string;
}