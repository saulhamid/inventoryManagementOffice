﻿export class Department {
    id: string;
    deptName: string;
    deptCode: string;
    branchId: string;
    branchName:string;

}