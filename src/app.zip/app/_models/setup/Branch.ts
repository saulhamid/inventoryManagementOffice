export class Branch {
    branchName: string;
    id: number;
    branchCode: string;
    companyId: string;
    companyName: string;
    address: string;
    phone: string;
    mobile: string;
    fax: string;
    vatRegNo: string;
    isSubBranch:boolean
}