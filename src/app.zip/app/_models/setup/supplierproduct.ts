export class SupplierProduct {
    supplyPrdId: string;
    productId: string;
    supplierId: string;
    supplierName: string;
    cpu: number;
    productName:string;
}