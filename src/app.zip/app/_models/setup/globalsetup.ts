export class EnvGlobalSetup {
    id: number;
    directIndent: boolean;
    multipleApprove: boolean;
    singleCompany: boolean;

}