export class Supplier {
    id: string;
    supplierName: string ;
mobile: string ;
phone: string ;
country: string ;
city: string ;
address: string ;
mailingAddress: string ;
email: string ;
url: string ;
contactPerson: string ;
isCreditPeriod: string ;
creditDays: string ;
dateOfEnrollment: string ;
isDiscontinue: string ;
}
