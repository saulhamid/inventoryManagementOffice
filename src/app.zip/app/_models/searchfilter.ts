export interface SearchCriteria {  
    isPageLoad: boolean;  
    filter: string;  
}  