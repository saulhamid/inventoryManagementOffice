export class designationVM {
    EmployeeName:string;
    EmployeeId:string;
    DesignationID:number;
    DesignationName: string;
}