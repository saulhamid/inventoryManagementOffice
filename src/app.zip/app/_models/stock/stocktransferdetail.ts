export class StockTransferDetails {
    stockTransferDetailId:string;
    ChallanNo:string;
    productId:string;
    productCode:string;
    productName:string;
    STReceiveQty:string;
    categoryName:string;
    subcategoryName:string;
    STQty:number
    StockQty:number
}
