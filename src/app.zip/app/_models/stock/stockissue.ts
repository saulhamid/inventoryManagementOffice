export class Stockissue {
  stockIssueDetailId:number;
  requisitionDetailId:number;
  requisitionId: string;
  branchId: string;
  rdt: string;
  employeeId: string;
  employyeName: string;
  deptName: string;
  SecName: string;
  branchName: string;
  groupname: string;
    productId: string;
    productName: string;
    productCode:string;
    categoryName:string;
    subCategoryName:string;
    uOMName:string;
    pStock: number;
    rQty:number;
    IssueBy:string;
    IssueDate:Date;
    qty:number;
    createdBy:string;
    createdDate:Date;
    isApproved:boolean;
    approvedDate:string;
    ApprovedBy:string;
    cons_qty:number;
    productStock:number;
    extraQty:number;
    ExtraQty22:number;
    reqty:number;
	
}