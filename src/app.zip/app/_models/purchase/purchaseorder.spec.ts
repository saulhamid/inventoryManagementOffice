import { Purchaseorder } from './purchaseorder';

describe('Purchaseorder', () => {
  it('should create an instance', () => {
    expect(new Purchaseorder()).toBeTruthy();
  });
});
