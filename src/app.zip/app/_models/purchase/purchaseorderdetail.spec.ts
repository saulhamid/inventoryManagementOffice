import { Purchaseorderdetail } from './purchaseorderdetail';

describe('Purchaseorderdetail', () => {
  it('should create an instance', () => {
    expect(new Purchaseorderdetail()).toBeTruthy();
  });
});
