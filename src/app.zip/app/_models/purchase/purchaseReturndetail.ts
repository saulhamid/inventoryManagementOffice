export class PurchaseReturndetail {
    pODId:string;
    pOId:string;
    productId:string;
    pOQty:string;
    pOOPrice:string;
    CPU:string;
    PRQty:string;
    categoryName:string;
    subCategoryName:string;
    uOMName:string;
    productName:string;
    disQty:string;
    disPrice:string;
}