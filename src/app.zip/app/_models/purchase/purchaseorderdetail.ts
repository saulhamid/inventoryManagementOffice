export class Purchaseorderdetail {
    pODId:string;
    pOId:string;
    productId:string;
    pOQty:string;
    pOOPrice:string;
    CPU:string;
    RPOQty:string;
    PORCVQty:string;
    tPORCVQty:string;
    categoryName:string;
    subCategoryName:string;
    uOMName:string;
    productName:string;
    disQty:string;
    disPrice:string;
    pRQty:number;
}