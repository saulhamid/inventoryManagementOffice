export class Purchaseorderavgcost {
    
    productId:string;
    productName:string;
    avg_cpu:number;
    sum_poqty:number;
    
}