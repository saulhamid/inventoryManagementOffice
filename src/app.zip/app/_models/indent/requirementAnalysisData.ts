export class RequirementAnalysisData {
    requisitionDetailId:number;
    ExtraQty:string;
    
}
