export class indentProceesPOVM {
    productId:string;
    indentId:string;
    productName:string;
    qty:string;
    cpu:string;
    stock:string;
    supplierid:string;
    poqty:string;
    porate:string;
}
