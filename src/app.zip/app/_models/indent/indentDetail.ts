export class IndentDetail {
    indentId:string;
    productid:string;
    productName:string;
    qty:string;
    categoryName:string;
    subcategoryName:string;
}
