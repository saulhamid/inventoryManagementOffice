export class employeeVM{
    employeeId: string;
}