﻿export class User {
    id: string;
    email: string;
    emailConfirmed: boolean;
    fullName: string;
    joinDate: string;
    firstname: string;
    lastName: string;
    Password: string;
    ConfirmPassword: string;
    username: string;
    employeeId: string;
employeeName: string ;
mobile: string ;
address: string ;
branchId: string ;
branchName: string ;
sectionId: string ;
sectionName: string ;
departmentId: string ;
departmentName: string ;
roleName: string ;
roleId: string ;
fullname: string ;
aspuserId:string;
userId:string;
}