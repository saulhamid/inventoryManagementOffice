export class Stockreceived {
}
