import { Stockissue } from './stockissue';

describe('Stockissue', () => {
  it('should create an instance', () => {
    expect(new Stockissue()).toBeTruthy();
  });
});
