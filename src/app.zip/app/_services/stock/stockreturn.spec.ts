import { Stockreturn } from './stockreturn';

describe('Stockreturn', () => {
  it('should create an instance', () => {
    expect(new Stockreturn()).toBeTruthy();
  });
});
