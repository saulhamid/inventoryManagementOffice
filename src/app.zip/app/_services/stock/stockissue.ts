export class Stockissue {
  rptType: string;
}
