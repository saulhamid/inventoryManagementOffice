export class Stockreturn {
}
