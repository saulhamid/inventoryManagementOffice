import { Stockissuereturn } from './stockissuereturn';

describe('Stockissuereturn', () => {
  it('should create an instance', () => {
    expect(new Stockissuereturn()).toBeTruthy();
  });
});
