export class Stockissuereturn {
}
