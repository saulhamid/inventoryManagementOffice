import { Stockreceived } from './stockreceived';

describe('Stockreceived', () => {
  it('should create an instance', () => {
    expect(new Stockreceived()).toBeTruthy();
  });
});
