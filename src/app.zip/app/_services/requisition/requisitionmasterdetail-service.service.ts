export class RequisitionmasterdetailService {
}
