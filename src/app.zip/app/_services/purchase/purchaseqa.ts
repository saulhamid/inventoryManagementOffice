export class Purchaseqa {
    
}
