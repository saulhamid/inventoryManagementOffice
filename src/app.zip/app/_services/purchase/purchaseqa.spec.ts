import { Purchaseqa } from './purchaseqa';

describe('Purchaseqa', () => {
  it('should create an instance', () => {
    expect(new Purchaseqa()).toBeTruthy();
  });
});
