export class IndentmasterdetailService {
}
